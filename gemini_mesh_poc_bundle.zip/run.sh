#!/bin/bash
echo "Running Gemini test script..."
python3 gemini_test.py
